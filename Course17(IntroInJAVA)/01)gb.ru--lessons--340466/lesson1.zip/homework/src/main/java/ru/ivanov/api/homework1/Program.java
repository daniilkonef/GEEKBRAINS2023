package ru.ivanov.api.homework1;

import ru.ivanov.api.MyUtils;

public class Program {

    public static void main(String[] args) {

        MyUtils.Sample();
    }

}
