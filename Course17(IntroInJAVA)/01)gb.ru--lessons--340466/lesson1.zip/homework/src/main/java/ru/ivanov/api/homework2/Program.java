package ru.ivanov.api.homework2;

public class Program {

    public static void main(String[] args) {

    }

}
