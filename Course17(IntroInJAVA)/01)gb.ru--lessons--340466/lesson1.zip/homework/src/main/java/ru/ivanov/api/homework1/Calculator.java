package ru.ivanov.api.homework1;

public class Calculator {

    public static void main(String[] args) {

    }

}
