package InterfaceIterator;

import java.util.List;

public class StudentGroup {
    private List<Student> studentsList;


    public List<Student> getStudentsList() {
        return studentsList;
    }

    public void setStudentsList(List<Student> studentsList) {
        this.studentsList = studentsList;
    }
}
