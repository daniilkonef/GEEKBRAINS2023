package ru.geekbrains.lesson1.sample;

import ru.geekbrains.lesson1.Product;

public class Program {

    public static void main(String[] args) {
        Product product1;

        product1 = new Product("ООО Лучшая вода", "Бу", -100.12);
        //product1.brand = "ООО Лучшая вода";
        //product1.name = "Бутылка с водой";
        //product1.price = -50;
        //product1.name = "A";
       // System.out.println(product1.displayInfo());
    }

}
