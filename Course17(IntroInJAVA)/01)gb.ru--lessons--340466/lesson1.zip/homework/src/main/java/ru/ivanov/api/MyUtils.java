package ru.ivanov.api;

public class MyUtils {

    public static void Sample(){

    }

}
